'use static'

export default {
  etymaAPI: 'etyma',
  wordAPI: 'word',
  articleAPI: 'article',
  nanhuarticleAPI: 'nanhuarticle',
  prefixAPI: 'prefix',
  suffixAPI: 'suffix',
  moduleAPI: 'module',
  modulesubAPI: 'modulesub',
  userAPI: 'user',
  loginAPI: 'login'
}

